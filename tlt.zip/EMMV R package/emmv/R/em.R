#' EM: Excess Mass
#'
#' @description
#' Method for plotting Product Functions (PFs) and Residue
#'
#' @param t LMD object created from LMD function
#' @param t_max Number of PFs to Plot
#' @param volume_support Whether to plot residue or not
#' @param s_unif color of plots
#' @param s_X Size of line in ggplot
#' @param n_generated Size of line in ggplot
#'
#' @return AUC = AUC, EM_t = EM_t, amax = amax
#' @author Shubhra Prakash, \email{shubhraprakash279@@gmail.com}
#' @keywords Excess Mass

#' @export em

em <- function(t, t_max, volume_support, s_unif, s_X, n_generated) {

EM_t <- rep(0, length(t))
n_samples <- length(s_X)
s_X_unique <- unique(s_X)
EM_t[1] <- 1

for (u in s_X_unique) {
  EM_t <- pmax(EM_t, (1 / n_samples) * sum(s_X > u) -
                 t * sum(s_unif > u) / n_generated * volume_support)
}

amax <- which.max(EM_t <= t_max)
if (amax == 1) {
  amax <- -1
}

AUC <- sum(diff(t[1:amax]) * EM_t[1:(amax - 1)])

return(list(AUC = AUC, EM_t = EM_t, amax = amax))
}

