#' EMMV
#'
#' @description
#' Get Excess-Mass (EM) and Mass Volume (MV) scores for unsupervised ML AD models
#'
#' @param trained_model LMD object created from LMD function
#' @param df Number of PFs to Plot
#' @param scoring_func Whether to plot residue or not
#' @param n_generated color of plots
#' @param alpha_min Size of line in ggplot
#' @param alpha_max Size of line in ggplot
#' @param t_max Size of line in ggplot
#'
#' @return ggplot plot for Product Functions (PFs) and Residue
#' @author Shubhra Prakash, \email{shubhraprakash279@@gmail.com}
#' @keywords EMMV Scores
#' @export emmv_scores

emmv_scores <- function(trained_model,
                        df,
                        scoring_func=NULL,
                        n_generated=10000,
                        alpha_min=0.9,
                        alpha_max=0.999,
                        t_max=0.9) {



lim_inf <- apply(df, 2, min)
lim_sup <- apply(df, 2, max)
offset <- 1e-60

tryCatch({
  volume_support <- prod(lim_sup - lim_inf) + offset
}, error = function(e) {
  volume_support <- (lim_sup - lim_inf) + offset
})

t <- seq(0, 100 / volume_support,by=0.01 / volume_support)
t <- t[-length(t)]
axis_alpha <- seq(alpha_min, alpha_max, by=0.0001)
axis_alpha <- axis_alpha[-length(axis_alpha)]

tryCatch({
  unif <- matrix(runif(n_generated * ncol(df), lim_inf, lim_sup), nrow = n_generated)
}, error = function(e) {
  unif <- runif(n_generated, lim_inf, lim_sup)
})


# # Get EM and MV scores
em_vals = em(t, t_max, volume_support, s_unif, anomaly_score, n_generated)
mv_vals = mv(axis_alpha, volume_support, s_unif, anomaly_score, n_generated)

# Return a dataframe containing EMMV information
scores <- list(
  'em' = mean(em_vals[["EM_t"]]),
  'mv' = mean(mv_vals[["mv"]])
)
return(scores)
}





