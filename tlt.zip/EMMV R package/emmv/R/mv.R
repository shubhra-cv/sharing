#' MV: Mass volume
#'
#' @description
#' Method for plotting Product Functions (PFs) and Residue
#'
#' @param axis_alpha LMD object created from LMD function
#' @param volume_support Number of PFs to Plot
#' @param s_unif Whether to plot residue or not
#' @param s_X color of plots
#' @param n_generated Size of line in ggplot
#'
#' @return ggplot plot for Product Functions (PFs) and Residue
#' @author Shubhra Prakash, \email{shubhraprakash279@@gmail.com}
#' @keywords AUC MV
#' @export mv

mv <- function(axis_alpha, volume_support, s_unif, s_X, n_generated) {
  n_samples <- length(s_X)
  s_X_argsort <- order(-s_X)
  mass <- 0
  cpt <- 0
  u <- s_X[s_X_argsort[1]]
  mv <- numeric(length(axis_alpha))

  for (i in seq_along(axis_alpha)) {
    while (mass < axis_alpha[i]) {
      cpt <- cpt + 1
      u <- s_X[s_X_argsort[cpt]]
      mass <- (1 / n_samples) * cpt
    }
    mv[i] <- sum(s_unif >= u) / n_generated * volume_support
  }

  auc <- sum(diff(axis_alpha) * mv[-length(mv)])
  return(list(AUC = auc, mv = mv))
}
